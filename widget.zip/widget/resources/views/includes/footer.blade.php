<div class = "row" id="error_block" style = "display:none">
        <div class = "col-md-12">
            <div style="bottom:50px" class="alert alert-danger alert-dismissible fade show text-center" role="alert">
                <strong id = "error_msg"></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
<div class="bot-nav" style = "bottom: 0;background: white;width: 100%;position:fixed">
    @yield('footer-btns')
</div>
