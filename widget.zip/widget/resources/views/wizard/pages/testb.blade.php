<!--Code By Webdevtrick ( https://webdevtrick.com )-->
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CSS Modal Nav | Webdevtrick.com</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <style>



    </style>

</head>
<body>


    <div style = "border-bottom-right-radius: 10px;border-bottom-left-radius: 10px;box-shadow: 5px 5px 10px #888888;height: 450px;width: 275px;margin: 50px;" class = "bab_saleperson_block">
        <div style = "width: inherit;height: 60%;position: relative;">
            <img style="display: block;max-width: 100%;object-fit: cover;height: 100%;margin: auto;width: 100%;" alt="" class="img-responsive" src="https://api.salesrater.net/uploads/media/profile_images/https://api.salesrater.net/uploads/media/profile_images/profile_homer_skelton_ford_corrina_jones_9eb48443_jpg" />
            <div style="font-family: Mulish;width: 100%;font-size: 25px;position: absolute;bottom: 0px;text-align: center;background-color: #272525c7;color: white;">Corrina Jones<br><span style = "font-family: Mulish;font-size:15px">Sales Agent</span></div>
        </div>
        <div style ="width:100%;text-align:center;padding-top: 10px;">
            <button style = "width:50%; padding-top: 20px;text-align:center;background-color: #ffff;border: 1px solid #2765B7;color: #2765B7;padding: 10px 20px;text-align: center;text-decoration: none;display: inline-block;margin: 4px 2px;cursor: pointer;border-radius: 30px;" >Connect</button>
        </div>
        <div style ="font-family: Mulish;font-size:18px;width:100%;text-align:center;padding-top: 10px;">(709)876-8857</div>
        <div style ="font-family: Mulish;font-size:18px;width:100%;text-align:center;padding-top: 5px;">testemail@testingemailyou.com</div>
        <div style = "display: grid;
            grid-template-columns: 33% 33% 33%;padding-top: 20px;">
            <div style="font-family: Mulish;font-size:13px;text-align: center;color: #757575;">Last 30 Sales<div style="font-weight: bold;font-size: 20;color: black;">10</div></div>
            <div style="font-family: Mulish;font-size:13px;text-align: center;color: #757575;">Reviews<div style="font-weight: bold;font-size: 20;color: black;">130</div></div>
            <div style="font-family: Mulish;font-size:13px;text-align: center;color: #757575;">Avg Stars<div style="font-weight: bold;font-size: 20;color: black;">4.8</div></div>
        </div>
    </div>



</body>
</html>

<script>



</script>
